import 'package:flutter/material.dart';
import 'nurse_notes_screen.dart';
import 'vitals_screen.dart';
import 'update_vitals_screen.dart';

class NursePatientDetailsScreen extends StatelessWidget {
  final String patientId;
  final String patientName;

  const NursePatientDetailsScreen({
    super.key,
    required this.patientId,
    required this.patientName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Patient Care Details"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.person),
              ),
              title: Text(patientName),
              subtitle: Text(
                "Patient ID: $patientId",
              ),
            ),
          ),
          const SizedBox(height: 20),
          _actionCard(
            context,
            "Update Vitals",
            Icons.favorite,
            UpdateVitalsScreen(
              patientId: patientId,
              patientName: patientName,
            ),
          ),
          _actionCard(
            context,
            "Vitals History",
            Icons.monitor_heart,
            VitalsScreen(
              patientId: patientId,
              patientName: patientName,
            ),
          ),
          _actionCard(
            context,
            "Add Nursing Notes",
            Icons.note,
            NurseNotesScreen(
              patientId: patientId,
              patientName: patientName,
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionCard(
    BuildContext context,
    String title,
    IconData icon,
    Widget screen,
  ) {
    return Card(
      child: ListTile(
        leading: Icon(
          icon,
          color: Colors.teal,
        ),
        title: Text(title),
        trailing: const Icon(
          Icons.arrow_forward_ios,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => screen,
            ),
          );
        },
      ),
    );
  }
}